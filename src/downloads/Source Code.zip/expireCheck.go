package main

import (
	"time"

	"fyne.io/fyne/v2"
)

func todoExpireDateCheck(todo []Data, a fyne.App) {
	for _, i := range todo {
		if !i.completed {
			var soon bool
			remaning_time := time.Until(i.expirationDate)
			if remaning_time < 0 {
				sendNotif("You have a task that exided the overdue date!", "Open ToDoInTime to check it out", a)
				soon = false
				break
			} else if remaning_time.Hours() < 24 && remaning_time > 0 {
				soon = true
			}
			if soon {
				sendNotif("You have a task that is gonna expire tomorrow!", "Open ToDoInTime to check it out", a)
				break
			}
		}
	}
}
