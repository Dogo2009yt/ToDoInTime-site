package main

import (
	"fmt"
	"image/color"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
	datepicker "github.com/sdassow/fyne-datepicker"
)

var lista *widget.List
var tasks []Data

func creaUI(dbPath string) {
	tasks = InitializeDB(dbPath, tasks)
	a := app.New()
	finestra := a.NewWindow("ToDoInTime")

	titoloTesto := widget.NewLabel("ToDoInTime")
	titoloTesto.TextStyle = fyne.TextStyle{Bold: true}

	lista = widget.NewList(
		func() int {
			return len(tasks)
		},
		func() fyne.CanvasObject {
			checkbox := widget.NewCheck("", nil)
			labelTitolo := widget.NewLabel("Titolo")
			labelData := widget.NewLabel("Data")
			return container.NewHBox(checkbox, labelTitolo, labelData)
		},
		func(i widget.ListItemID, o fyne.CanvasObject) {
			row := o.(*fyne.Container)
			check := row.Objects[0].(*widget.Check)
			labelTitolo := row.Objects[1].(*widget.Label)
			labelData := row.Objects[2].(*widget.Label)

			task := tasks[i]
			labelTitolo.SetText(task.title)
			labelData.SetText(task.expirationDate.Format("02/01/2006"))
			check.SetChecked(task.completed)
			check.OnChanged = func(c bool) {
				tasks[i].completed = c
				WriteDB(dbPath, tasks)
			}
		},
	)

	lista.OnSelected = func(id widget.ListItemID) {
		dettagliTask(id, a, dbPath)
	}

	addBtn := widget.NewButtonWithIcon(
		"Add",
		theme.ContentAddIcon(),
		func() {
			addTaskWindow(a, dbPath)
		},
	)
	addBtn.Importance = widget.HighImportance

	finestra.SetContent(
		container.NewBorder(
			container.NewCenter(titoloTesto),
			addBtn,
			nil, nil,
			lista,
		),
	)

	finestra.Resize(fyne.NewSize(400, 300))
	finestra.ShowAndRun()
}

func dettagliTask(id widget.ListItemID, a fyne.App, dbPath string) {
	task := tasks[id]
	dettaglio := a.NewWindow(task.title)

	titoloText := widget.NewLabel("Title:")
	titoloTask := widget.NewLabel(task.title)
	titoloText.TextStyle = fyne.TextStyle{Bold: true}
	titolo := container.NewHBox(titoloText, titoloTask)

	bodyText := widget.NewLabel("Description:")
	bodyTask := widget.NewLabel(task.body)
	bodyText.TextStyle = fyne.TextStyle{Bold: true}
	body := container.NewHBox(bodyText, bodyTask)

	dateText := widget.NewLabel("Expiration date:")
	dateTask := widget.NewLabel(task.expirationDate.Format("02/01/2006"))
	dateText.TextStyle = fyne.TextStyle{Bold: true}
	date := container.NewHBox(dateText, dateTask)

	modificaBtn := widget.NewButtonWithIcon(
		"Edit",
		theme.DocumentCreateIcon(),
		func() {
			modifyTaskWindow(a, id, dbPath)
		},
	)
	modificaBtn.Importance = widget.HighImportance

	eliminaBtn := widget.NewButtonWithIcon(
		"Delete",
		theme.DeleteIcon(),
		func() {
			dialog.ShowConfirm("Confirm", "Are you sure to delete it?", func(b bool) {
				if b {
					tasks = append(tasks[:id], tasks[id+1:]...)
					WriteDB(dbPath, tasks)
					lista.Refresh()
					dettaglio.Hide()
				}
			}, dettaglio)
		},
	)
	eliminaBtn.Importance = widget.DangerImportance

	rect := canvas.NewRectangle(color.Transparent)
	rect.SetMinSize(fyne.NewSize(200, 15))

	dettaglio.SetContent(
		container.NewCenter(
			container.NewVBox(
				titolo,
				body,
				date,
				rect,
				modificaBtn,
				eliminaBtn,
			),
		),
	)
	dettaglio.Resize(fyne.NewSize(300, 200))
	dettaglio.Show()
}

func addTaskWindow(a fyne.App, dbPath string) {
	aggiungi := a.NewWindow("Add task")

	title := widget.NewLabel("Add Task")
	title.TextStyle = fyne.TextStyle{Bold: true}

	input1 := widget.NewEntry()
	input1.SetPlaceHolder("Enter task Title...")
	input2 := widget.NewEntry()
	input2.SetPlaceHolder("Enter task description...")

	when := time.Now()
	var selectedDate time.Time
	var input3btn *widget.Button
	input3 := datepicker.NewDatePicker(when, time.Monday, func(when time.Time, ok bool) {
		if ok {
			selectedDate = when
			input3btn.SetText(selectedDate.Format("02/01/2006"))
		}
		aggiungi.Resize(fyne.NewSize(400, 200))
	})

	input3btn = widget.NewButton("Select date", func() {
		d := dialog.NewCustomConfirm(
			"Choose date", "Ok", "Cancel",
			input3, input3.OnActioned, aggiungi,
		)
		aggiungi.Resize(fyne.NewSize(400, 400))
		d.Show()
	})

	form := &widget.Form{
		Items: []*widget.FormItem{
			{Text: "Task Title:", Widget: input1},
			{Text: "Task Description:", Widget: input2},
			{Text: "Task Expiration date:", Widget: input3btn},
		},
	}

	submitBtn := widget.NewButton("Save Task", func() {
		if input1.Text == "" || input2.Text == "" || selectedDate.IsZero() {
			dialog.ShowError(fmt.Errorf("Compila tutti i campi"), aggiungi)
			return
		}
		taskAdd(input1.Text, input2.Text, selectedDate, dbPath)
		lista.Refresh()
		aggiungi.Close()
	})
	submitBtn.Importance = widget.HighImportance

	rect := canvas.NewRectangle(color.Transparent)
	rect.SetMinSize(fyne.NewSize(200, 15))
	rect1 := canvas.NewRectangle(color.Transparent)
	rect1.SetMinSize(fyne.NewSize(200, 5))

	aggiungi.SetContent(
		container.NewVBox(
			container.NewCenter(title),
			rect1,
			container.NewVBox(form, rect, submitBtn),
		),
	)
	aggiungi.Resize(fyne.NewSize(400, 200))
	aggiungi.Show()
}

func taskAdd(newTitle string, newBody string, expDate time.Time, dbPath string) {
	add := Data{
		title:          newTitle,
		body:           newBody,
		expirationDate: expDate,
	}
	tasks = append(tasks, add)
	WriteDB(dbPath, tasks)
}

func modifyTaskWindow(a fyne.App, id widget.ListItemID, dbPath string) {
	modifica := a.NewWindow("Edit task")

	title := widget.NewLabel("Edit Task")
	title.TextStyle = fyne.TextStyle{Bold: true}
	task := tasks[id]

	input1 := widget.NewEntry()
	input1.SetPlaceHolder("Enter task Title...")
	input1.SetText(task.title)

	input2 := widget.NewEntry()
	input2.SetPlaceHolder("Enter task description...")
	input2.SetText(task.body)

	selectedDate := task.expirationDate
	var input3btn *widget.Button
	input3 := datepicker.NewDatePicker(task.expirationDate, time.Monday, func(when time.Time, ok bool) {
		if ok {
			selectedDate = when
			input3btn.SetText(selectedDate.Format("02/01/2006"))
		}
		modifica.Resize(fyne.NewSize(400, 200))
	})

	input3btn = widget.NewButton(task.expirationDate.Format("02/01/2006"), func() {
		d := dialog.NewCustomConfirm(
			"Choose date", "Ok", "Cancel",
			input3, input3.OnActioned, modifica,
		)
		modifica.Resize(fyne.NewSize(400, 400))
		d.Show()
	})

	form := &widget.Form{
		Items: []*widget.FormItem{
			{Text: "Task Title:", Widget: input1},
			{Text: "Task Description:", Widget: input2},
			{Text: "Task Expiration date:", Widget: input3btn},
		},
	}

	submitBtn := widget.NewButton("Save Task", func() {
		if input1.Text == "" || input2.Text == "" {
			dialog.ShowError(fmt.Errorf("Compila tutti i campi"), modifica)
			return
		}
		taskEdit(int(id), input1.Text, input2.Text, selectedDate, dbPath)
		lista.Refresh()
		modifica.Close()
	})
	submitBtn.Importance = widget.HighImportance

	rect := canvas.NewRectangle(color.Transparent)
	rect.SetMinSize(fyne.NewSize(200, 15))
	rect1 := canvas.NewRectangle(color.Transparent)
	rect1.SetMinSize(fyne.NewSize(200, 5))

	modifica.SetContent(
		container.NewVBox(
			container.NewCenter(title),
			rect1,
			container.NewVBox(form, rect, submitBtn),
		),
	)
	modifica.Resize(fyne.NewSize(400, 200))
	modifica.Show()
}

func taskEdit(taskID int, newTitle string, newBody string, expDate time.Time, dbPath string) {
	tasks[taskID] = Data{
		title:          newTitle,
		body:           newBody,
		expirationDate: expDate,
		completed:      tasks[taskID].completed,
	}
	WriteDB(dbPath, tasks)
}
