package main

import _ "embed"

//go:embed db/db.txt
var initialDB []byte
