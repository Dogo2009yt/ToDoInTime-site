package main

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

func InitializeDB(fileName string, todo []Data) ([]Data) {
	file, err := os.Open(fileName)
	if err != nil { fmt.Println("Error while openinig DB file [init fase]", err) ; return nil }

	r := bufio.NewReader(file)
	for {
		line, err := r.ReadString('\n')
		line = strings.TrimSpace(line)
		if len(line) > 0 {
			lineArray := strings.Split(line, "$")
			expDate := strings.TrimSpace(lineArray[2])
			newDate, err := time.Parse("2006-01-02", expDate)
			if err != nil { log.Fatal("\n\nERROR: not a valid date format found in DB\n") }
			completationTrimmed := strings.TrimSpace(lineArray[3])
			completation, err := strconv.ParseBool(completationTrimmed)
			if err != nil { log.Fatal("\n\nERROR: not a valid completation status format found in DB\n") }
			add := Data{
				title:          lineArray[0],
				body:           lineArray[1],
				expirationDate: newDate,
				completed: completation,
			}
			todo = append(todo, add)
		}
		if err != nil {
			if err == io.EOF { break }
			fmt.Print("Error while rading DB file", err) ; return nil }
	}
	return todo
}

func WriteDB(fileName string, todo []Data) {
	file, err := os.OpenFile(fileName, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0644)
	if err != nil { fmt.Println("Error while opening DB file [writing fase]", err) ; return }

	writer := bufio.NewWriter(file)

	for _, task := range todo {
    line := fmt.Sprintf("%s$%s$%s$%t", task.title, task.body, task.expirationDate.Format("2006-01-02"), task.completed)
    _, err := fmt.Fprintln(writer, line)
    if err != nil { fmt.Println("Error while writing DB file", err) ; return }
}

	if err := writer.Flush(); err != nil {
        fmt.Println("Errore while flushing writer buffer", err)
    }
}
