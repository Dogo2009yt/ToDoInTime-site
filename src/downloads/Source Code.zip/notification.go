package main

import (
	"fyne.io/fyne/v2"
)

func sendNotif(title, message string, a fyne.App) {
	a.SendNotification(&fyne.Notification{
		Title:   title,
		Content: message,
	})
}
