package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

func printUI(todo []Data) {
	p := fmt.Println
	p("\n-----TODO IN TIME-----")
	p("1 | Display the list of tasks")
	p("2 | Add a task")
	p("3 | Change the text of a task")
	p("4 | Change the completation status of a task")
	p("5 | Exit ToDoInTime")
	fmt.Print(">>> ")
	var selection string
	fmt.Scanln(&selection)

	selectInt, err := strconv.Atoi(selection)
	if err != nil || selectInt < 1 || selectInt > 5 {
		log.Fatal("ERROR: not a valid selection")
	}

	switch selectInt {
	case 1:
		printList(todo)
	case 2:
		addTask(todo)
	case 3:
		changeFront(todo)
	case 4:
		changeData(todo)
	case 5:
		os.Exit(0)
	}
}

func printList(todo []Data) {
	p := fmt.Println
	pf := fmt.Printf
	if len(todo) != 0 {
		for i := range len(todo) {
			pf("-- %q -- compleated %v\n", todo[i].title, todo[i].completed)
			p(todo[i].body)
			pf("expire %v (yy/mm/dd hour:min:sec timeZone)\n\n", todo[i].expirationDate)
		}
	} else {
		p("No task avaliable, create one first\n")
		printUI(todo)
	}
	printUI(todo)
}

func addTask(todo []Data) {
	p := fmt.Print
	r := bufio.NewReader(os.Stdin)
	var (
		newTitle string
		newBody  string
		expDate  string
	)

	p("Task title | ")
	newTitle, err := r.ReadString('\n')
	if err != nil {
		log.Fatal(err)
	}
	newTitle = strings.TrimSpace(newTitle)
	p("Task body | ")
	newBody, err = r.ReadString('\n')
	if err != nil {
		log.Fatal(err)
	}
	newBody = strings.TrimSpace(newBody)
	p("Task expiration date (yyyy-mm-dd) | ")
	expDate, err = r.ReadString('\n')
	if err != nil {
		log.Fatal(err)
	}
	expDate = strings.TrimSpace(expDate)
	newDate, err := time.Parse("2006-01-02", expDate)
	if err != nil { log.Fatal("\n\nERROR: not a valid date format\n") }

	add := Data{
		title:          newTitle,
		body:           newBody,
		expirationDate: newDate,
	}
	todo = append(todo, add)
	WriteDB("db/db.txt", todo)
	printUI(todo)
}

var found bool = false
func changeFront(todo []Data) {
	found = false
	r := bufio.NewReader(os.Stdin)
	fmt.Print("Insert the title of the task you wanna change the status | ")
	Title, err := r.ReadString('\n')
	if err != nil { log.Fatal(err) }
	Title = strings.TrimSpace(Title)
	for i, task := range todo {
		if Title != task.title {
			continue
		}
		found = true
		var choice string
		fmt.Print("What do you want to change (title, body, date) | ")
		choice, err := r.ReadString('\n')
		if err != nil { log.Fatal(err) }
		choice = strings.TrimSpace(choice)
		choice = strings.ToUpper(choice)
		switch choice {
			case "TITLE":
				var Ntitle string
				fmt.Print("Insert new title | ")
				Ntitle, err := r.ReadString('\n')
				if err != nil { log.Fatal(err) }
				Ntitle = strings.TrimSpace(Ntitle)
				todo[i].title = Ntitle
			case "BODY":
				var Nbody string
				fmt.Print("Insert new body | ")
				Nbody, err := r.ReadString('\n')
				if err != nil { log.Fatal(err) }
				Nbody = strings.TrimSpace(Nbody)
				todo[i].body = Nbody
			case "DATE":
				var Ndate string
				fmt.Print("Insert new date (yy-mm-dd) | ")
				Ndate, err := r.ReadString('\n')
				if err != nil { log.Fatal(err) }
				Ndate = strings.TrimSpace(Ndate)
				NNdate, err := time.Parse("2006-01-02", Ndate)
				if err != nil { fmt.Println("ERROR not a valid date format") ; return}
				todo[i].expirationDate = NNdate
			default:
				fmt.Println("Not a valid selection, program restarted")
				printUI(todo)
		}
	}

	if found == false {
		fmt.Println("Task not found")
		printUI(todo)
	}

	WriteDB("db/db.txt", todo)
	printUI(todo)
}

func changeData(todo []Data) {
	found = false
	r := bufio.NewReader(os.Stdin)
	fmt.Print("Insert the title of the task you wanna change the status | ")
	Title, err := r.ReadString('\n')
	if err != nil { log.Fatal(err) }
	Title = strings.TrimSpace(Title)
	for i, task := range todo {
		if Title != task.title {
			continue
		}
		found = true
		if !task.completed {
			todo[i].completed = true
			fmt.Print("Do you wanna delete this compleated task? (y/n) | ")
			var selection string
			fmt.Scanln(&selection)
			if strings.ToUpper(selection) == "Y" {
				todo = append(todo[:i], todo[i+1:]...)
			} else {
				fmt.Println("Input counted as 'no'")
			}
		} else {
			todo[i].completed = false
		}
	}
	if found == false {
		fmt.Println("Task not found")
		printUI(todo)
	}

	WriteDB("db/db.txt", todo)
	printUI(todo)
}
