package main

import (
    "os"
    "path/filepath"
    "time"
    "fyne.io/fyne/v2"
    "fyne.io/fyne/v2/app"
)

type Data struct {
    title          string
    body           string
    expirationDate time.Time
    completed      bool
}

func main() {
    var todo []Data
    a := app.NewWithID("ToDoInTime")

    dbPath := initDB(a)

    todo = InitializeDB(dbPath, todo)
    todoExpireDateCheck(todo, a)
    creaUI(dbPath)
}

func initDB(a fyne.App) string {
    dbPath := filepath.Join(a.Storage().RootURI().Path(), "db.txt")

    if _, err := os.Stat(dbPath); os.IsNotExist(err) {
        os.WriteFile(dbPath, initialDB, 0644)
    }

    return dbPath
}
